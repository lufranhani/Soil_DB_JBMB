# ==============================================================
# 1. Load Packages
# ==============================================================
library(ggplot2)
library(ggcorrplot)
library(readxl)
library(RColorBrewer)
library(gridExtra)

# ==============================================================
# 2. Read Data
# ==============================================================
#setwd("")
rm(list = ls())

df_dws <- read_excel("Pearson_1.xlsx")
df_ssf  <- read_excel("Pearson_1.xlsx", sheet = 2)
df_da  <- read_excel("Pearson_1.xlsx", sheet = 3)

# ==============================================================
# 3. Define Color Palette
# ==============================================================
pal <- colorRampPalette(brewer.pal(11, "RdBu"))(3)

# ==============================================================
# 4. Create Function for Pearson Correlation Plot
# ==============================================================
make_corrplot <- function(data, title) {
  
  cor.res  <- cor(data[, 1:9], method = "pearson")
  testRes  <- psych::corr.test(data[, 1:9], adjust = "none")
  p.mat    <- testRes$p
  
  ggcorrplot(
    cor.res,
    p.mat = p.mat,
    sig.level = 0.05,
    type = "lower",
    hc.order = FALSE,
    lab = TRUE,
    lab_size = 3,
    colors = pal,
    method = "square",
    ggtheme = theme_bw,
    #title = title,
    insig = "blank"
  )+
    theme(
      axis.text.x  = element_blank(),
      axis.text.y  = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank()
    )
}

# ==============================================================
# 5. Generate Three Correlation Plots
# ==============================================================
p1 <- make_corrplot(df_dws, "DWS – Pearson Correlation Matrix")
p2 <- make_corrplot(df_ssf, "SSF – Pearson Correlation Matrix")
p3 <- make_corrplot(df_da, "DA – Pearson Correlation Matrix")

# ==============================================================
# 6. Arrange Plots Side by Side
# ==============================================================
combined_plot <- grid.arrange(p1, p2, p3, ncol = 3)

combined_plot

#####
#####
### Depth 2
df_dws2 <- read_excel("Pearson_2.xlsx")
df_ssf2  <- read_excel("Pearson_2.xlsx", sheet = 2)
df_da2  <- read_excel("Pearson_2.xlsx", sheet = 3)

# Define Color Palette==============================================================
pal <- colorRampPalette(brewer.pal(11, "RdBu"))(3)

# Create Function for Pearson Correlation Plot==============================================================
make_corrplot <- function(data, title) {
  
  cor.res  <- cor(data[, 1:9], method = "pearson")
  testRes  <- psych::corr.test(data[, 1:9], adjust = "none")
  p.mat    <- testRes$p
  
  ggcorrplot(
    cor.res,
    p.mat = p.mat,
    sig.level = 0.05,
    type = "lower",
    hc.order = FALSE,
    lab = TRUE,
    lab_size = 3,
    colors = pal,
    method = "square",
    ggtheme = theme_bw,
    #title = title,
    insig = "blank"
  )+
    theme(
      axis.text.x  = element_blank(),
      axis.text.y  = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank()
    )
}

# Generate Three Correlation Plots==============================================================
p4 <- make_corrplot(df_dws2, "DWS – Pearson Correlation Matrix")
p5 <- make_corrplot(df_ssf2, "SSF – Pearson Correlation Matrix")
p6 <- make_corrplot(df_da2, "DA – Pearson Correlation Matrix")

# Arrange Plots Side by Side==============================================================
combined_plot2 <- grid.arrange(p4, p5, p6, ncol = 3)

combined_plot2

### Depth 3
df_dws3 <- read_excel("Pearson_3.xlsx")
df_da3  <- read_excel("Pearson_3.xlsx", sheet = 2)
df_ssf3  <- read_excel("Pearson_3.xlsx", sheet = 3)

# Define Color Palette==============================================================
pal <- colorRampPalette(brewer.pal(11, "RdBu"))(3)

# Create Function for Pearson Correlation Plot==============================================================
make_corrplot <- function(data, title) {
  
  cor.res  <- cor(data[, 1:9], method = "pearson")
  testRes  <- psych::corr.test(data[, 1:9], adjust = "none")
  p.mat    <- testRes$p
  
  ggcorrplot(
    cor.res,
    p.mat = p.mat,
    sig.level = 0.05,
    type = "lower",
    hc.order = FALSE,
    lab = TRUE,
    lab_size = 3,
    colors = pal,
    method = "square",
    ggtheme = theme_bw,
    #title = title,
    insig = "blank"
  )+
    theme(
      axis.text.x  = element_blank(),
      axis.text.y  = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank()
    )
}

# Generate Three Correlation Plots==============================================================
p7 <- make_corrplot(df_dws3, "DWS – Pearson Correlation Matrix")
p8 <- make_corrplot(df_ssf3, "SSF – Pearson Correlation Matrix")
p9 <- make_corrplot(df_da3, "DA – Pearson Correlation Matrix")

# Arrange Plots Side by Side==============================================================
combined_plot3 <- grid.arrange(p7, p8, p9, ncol = 3)

combined_plot3


### Depth 4
df_dws4 <- read_excel("Pearson_4.xlsx")
df_da4  <- read_excel("Pearson_4.xlsx", sheet = 2)
df_ssf4  <- read_excel("Pearson_4.xlsx", sheet = 3)

# Define Color Palette==============================================================
pal <- colorRampPalette(brewer.pal(11, "RdBu"))(3)

# Create Function for Pearson Correlation Plot==============================================================
make_corrplot <- function(data, title) {
  
  cor.res  <- cor(data[, 1:9], method = "pearson")
  testRes  <- psych::corr.test(data[, 1:9], adjust = "none")
  p.mat    <- testRes$p
  
  ggcorrplot(
    cor.res,
    p.mat = p.mat,
    sig.level = 0.05,
    type = "lower",
    hc.order = FALSE,
    lab = TRUE,
    lab_size = 3,
    colors = pal,
    method = "square",
    ggtheme = theme_bw,
   # title = title,
    insig = "blank"
  )+
    theme(
      axis.text.x  = element_blank(),
      axis.text.y  = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank()
    )
}

# Generate Three Correlation Plots==============================================================
p10 <- make_corrplot(df_dws4, "DWS – Pearson Correlation Matrix")
p11 <- make_corrplot(df_ssf4, "SSF – Pearson Correlation Matrix")
p12 <- make_corrplot(df_da4, "DA – Pearson Correlation Matrix")

# Arrange Plots Side by Side==============================================================
combined_plot4 <- grid.arrange(p10, p11, p12, ncol = 3)


### Depth 5
df_dws5 <- read_excel("Pearson_5.xlsx")
df_da5  <- read_excel("Pearson_5.xlsx", sheet = 2)
df_ssf5  <- read_excel("Pearson_5.xlsx", sheet = 3)

# Define Color Palette==============================================================
pal <- colorRampPalette(brewer.pal(11, "RdBu"))(3)

# Create Function for Pearson Correlation Plot==============================================================
make_corrplot <- function(data, title) {
  
  cor.res  <- cor(data[, 1:9], method = "pearson")
  testRes  <- psych::corr.test(data[, 1:9], adjust = "none")
  p.mat    <- testRes$p
  
  ggcorrplot(
    cor.res,
    p.mat = p.mat,
    sig.level = 0.05,
    type = "lower",
    hc.order = FALSE,
    lab = TRUE,
    lab_size = 3,
    colors = pal,
    method = "square",
    ggtheme = theme_bw,
   # title = title,
    insig = "blank"
  )+
    theme(
      axis.text.x  = element_blank(),
      axis.text.y  = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank()
    )
}

# Generate Three Correlation Plots==============================================================
p13 <- make_corrplot(df_dws5, "DWS – Pearson Correlation Matrix")
p14 <- make_corrplot(df_ssf5, "SSF – Pearson Correlation Matrix")
p15 <- make_corrplot(df_da5, "DA – Pearson Correlation Matrix")

# Arrange Plots Side by Side==============================================================
combined_plot5 <- grid.arrange(p13, p14, p15, ncol = 3)
combined_plot5



# ==============================================================
# Combine the Five Depth Panels Into a Single Figure
# ==============================================================

final_plot <- grid.arrange(
  combined_plot,
  combined_plot2,
  combined_plot3,
  combined_plot4,
  combined_plot5,
  ncol = 1
)

final_plot
